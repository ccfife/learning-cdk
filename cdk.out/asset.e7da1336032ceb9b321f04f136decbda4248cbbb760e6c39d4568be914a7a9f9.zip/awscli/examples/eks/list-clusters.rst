**To list your available clusters**

This example command lists all of your available clusters in your default region.

Command::

  aws eks list-clusters

Output::

    {
        "clusters": [
            "devel",
            "prod"
        ]
    }
