**To delete a cluster**

This example command deletes a cluster named `devel` in your default region.

Command::

  aws eks delete-cluster --name devel
